
-- 1. Tạo cơ sở dữ liệu
CREATE DATABASE QUANLYSINHVIEN;
GO

-- 2. Sử dụng cơ sở dữ liệu
USE QUANLYSINHVIEN;
GO

-- 3. Tạo bảng SinhVien
CREATE TABLE SinhVien (
    MaSinhVien VARCHAR(20) PRIMARY KEY,
    HoVaTen NVARCHAR(100) NOT NULL,
    NamSinh INT NOT NULL,
    GioiTinh NVARCHAR(10)
);
GO

-- 4. Tạo bảng MonHoc
CREATE TABLE MonHoc (
    MaMonHoc VARCHAR(20) PRIMARY KEY,
    TenMonHoc NVARCHAR(100) NOT NULL
);
GO

-- 5. Tạo bảng DangKyMonHoc
CREATE TABLE DangKyMonHoc (
    MaSinhVien VARCHAR(20),
    MaMonHoc VARCHAR(20),

    PRIMARY KEY (MaSinhVien, MaMonHoc),

    FOREIGN KEY (MaSinhVien)
    REFERENCES SinhVien(MaSinhVien),

    FOREIGN KEY (MaMonHoc)
    REFERENCES MonHoc(MaMonHoc)
);
GO

-- 6. Thêm dữ liệu sinh viên
INSERT INTO SinhVien
VALUES
('SV001', N'Nguyễn Văn An', 2005, N'Nam'),
('SV002', N'Trần Thị Bình', 2004, N'Nữ'),
('SV003', N'Lê Văn Cường', 2005, N'Nam'),
('SV004', N'Phạm Thị Dung', 2006, N'Nữ');
GO

-- 7. Thêm dữ liệu môn học
INSERT INTO MonHoc
VALUES
('MH001', N'Lập trình Java'),
('MH002', N'Cơ sở dữ liệu'),
('MH003', N'Lập trình C++'),
('MH004', N'Thiết kế Web');
GO

-- 8. Thêm dữ liệu đăng ký môn học
INSERT INTO DangKyMonHoc
VALUES
('SV001', 'MH001'),
('SV001', 'MH002'),
('SV002', 'MH003'),
('SV003', 'MH001'),
('SV004', 'MH004');
GO

-- 9. Truy vấn danh sách sinh viên và môn học
SELECT
    SV.MaSinhVien,
    SV.HoVaTen,
    SV.NamSinh,
    SV.GioiTinh,
    MH.MaMonHoc,
    MH.TenMonHoc
FROM SinhVien SV
LEFT JOIN DangKyMonHoc DK
    ON SV.MaSinhVien = DK.MaSinhVien
LEFT JOIN MonHoc MH
    ON DK.MaMonHoc = MH.MaMonHoc;
GO
