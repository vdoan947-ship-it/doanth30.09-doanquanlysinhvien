
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GiaoDienQuanLySinhVien extends JFrame {

    // THONG TIN KET NOI SQL SERVER
    private final String URL =
        "jdbc:sqlserver://localhost:1433;" +
        "databaseName=QUANLYSINHVIEN;" +
        "encrypt=true;" +
        "trustServerCertificate=true;";

    private final String USER = "sa";
    private final String PASSWORD = "123456";

    private Connection conn;

    private JTextField txtMaSV, txtHoTen, txtNamSinh;
    private JTextField txtMaMH, txtTenMH, txtTimKiem;
    private JComboBox<String> cbGioiTinh;

    private JTable table;
    private DefaultTableModel model;

    public GiaoDienQuanLySinhVien() {

        setTitle("QUAN LY SINH VIEN");
        setSize(1050, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        taoGiaoDien();
        ketNoiSQL();
        hienThiDanhSach();
    }

    // =====================================
    // 1. KET NOI SQL SERVER
    // =====================================

    private void ketNoiSQL() {
        try {
            Class.forName(
                "com.microsoft.sqlserver.jdbc.SQLServerDriver"
            );

            conn = DriverManager.getConnection(
                URL, USER, PASSWORD
            );

            JOptionPane.showMessageDialog(
                this,
                "KET NOI SQL SERVER THANH CONG!"
            );

        } catch (Exception e) {
            conn = null;

            JOptionPane.showMessageDialog(
                this,
                "KET NOI SQL THAT BAI!\n" + e.getMessage()
            );
        }
    }

    // =====================================
    // 2. TAO GIAO DIEN
    // =====================================

    private void taoGiaoDien() {

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JLabel title = new JLabel(
            "QUAN LY SINH VIEN",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(Color.BLUE);

        main.add(title, BorderLayout.NORTH);

        // FORM NHAP THONG TIN
        JPanel form = new JPanel(new GridLayout(3, 4, 10, 10));

        form.setBorder(
            BorderFactory.createTitledBorder(
                "THONG TIN SINH VIEN"
            )
        );

        txtMaSV = new JTextField();
        txtHoTen = new JTextField();
        txtNamSinh = new JTextField();

        cbGioiTinh = new JComboBox<>(
            new String[]{"Nam", "Nu", "Khac"}
        );

        txtMaMH = new JTextField();
        txtTenMH = new JTextField();

        form.add(new JLabel("Ma sinh vien:"));
        form.add(txtMaSV);

        form.add(new JLabel("Ho va ten:"));
        form.add(txtHoTen);

        form.add(new JLabel("Nam sinh:"));
        form.add(txtNamSinh);

        form.add(new JLabel("Gioi tinh:"));
        form.add(cbGioiTinh);

        form.add(new JLabel("Ma mon hoc:"));
        form.add(txtMaMH);

        form.add(new JLabel("Ten mon hoc:"));
        form.add(txtTenMH);

        // CAC NUT CHUC NANG
        JButton btnThem = new JButton("THEM");
        JButton btnSua = new JButton("SUA");
        JButton btnXoa = new JButton("XOA");
        JButton btnLamMoi = new JButton("LAM MOI");

        JPanel buttons = new JPanel();

        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnLamMoi);

        JPanel top = new JPanel(new BorderLayout(10, 10));

        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        // BANG DU LIEU
        model = new DefaultTableModel(
            new String[]{
                "Ma SV",
                "Ho va ten",
                "Nam sinh",
                "Gioi tinh",
                "Ma mon hoc",
                "Ten mon hoc"
            }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(27);

        JScrollPane scroll = new JScrollPane(table);

        // TIM KIEM
        txtTimKiem = new JTextField(20);

        JButton btnTim = new JButton("TIM KIEM");
        JButton btnTaiLai = new JButton("TAI LAI");

        JPanel search = new JPanel();

        search.add(new JLabel("Tim theo ma SV hoac ho ten:"));
        search.add(txtTimKiem);
        search.add(btnTim);
        search.add(btnTaiLai);

        JPanel center = new JPanel(new BorderLayout(10, 10));

        center.add(top, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);
        center.add(search, BorderLayout.SOUTH);

        main.add(center, BorderLayout.CENTER);

        add(main);

        // SU KIEN CAC NUT
        btnThem.addActionListener(e -> themSinhVien());

        btnSua.addActionListener(e -> suaSinhVien());

        btnXoa.addActionListener(e -> xoaSinhVien());

        btnLamMoi.addActionListener(e -> lamMoi());

        btnTim.addActionListener(e -> timKiem());

        btnTaiLai.addActionListener(e -> {
            txtTimKiem.setText("");
            hienThiDanhSach();
        });

        // CHON DU LIEU TREN BANG
        table.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {

                int row = table.getSelectedRow();

                if (row >= 0) {

                    txtMaSV.setText(
                        model.getValueAt(row, 0).toString()
                    );

                    txtHoTen.setText(
                        model.getValueAt(row, 1).toString()
                    );

                    txtNamSinh.setText(
                        model.getValueAt(row, 2).toString()
                    );

                    cbGioiTinh.setSelectedItem(
                        model.getValueAt(row, 3).toString()
                    );

                    Object maMH = model.getValueAt(row, 4);
                    Object tenMH = model.getValueAt(row, 5);

                    txtMaMH.setText(
                        maMH == null ? "" : maMH.toString()
                    );

                    txtTenMH.setText(
                        tenMH == null ? "" : tenMH.toString()
                    );

                    txtMaSV.setEditable(false);
                }
            }
        });
    }

    // =====================================
    // 3. KIEM TRA DU LIEU
    // =====================================

    private boolean kiemTraDuLieu() {

        if (txtMaSV.getText().trim().isEmpty()
                || txtHoTen.getText().trim().isEmpty()
                || txtNamSinh.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Vui long nhap ma SV, ho ten va nam sinh!"
            );

            return false;
        }

        try {
            int nam = Integer.parseInt(
                txtNamSinh.getText().trim()
            );

            if (nam < 1900 || nam > 2100) {
                JOptionPane.showMessageDialog(
                    this, "Nam sinh khong hop le!"
                );
                return false;
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this, "Nam sinh phai la so!"
            );

            return false;
        }

        if (txtMaMH.getText().trim().isEmpty()
                != txtTenMH.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Phai nhap ca ma mon hoc va ten mon hoc!"
            );

            return false;
        }

        return true;
    }

    // =====================================
    // 4. LUU MON HOC VA DANG KY
    // =====================================

    private void luuMonHoc(String maSV) throws SQLException {

        String maMH = txtMaMH.getText().trim();
        String tenMH = txtTenMH.getText().trim();

        // Neu khong nhap mon hoc thi bo qua
        if (maMH.isEmpty()) {
            return;
        }

        // Them mon hoc neu chua ton tai,
        // neu da ton tai thi cap nhat ten mon hoc
        String sqlMH =
            "IF EXISTS (SELECT 1 FROM MonHoc WHERE MaMonHoc=?) " +
            "UPDATE MonHoc SET TenMonHoc=? WHERE MaMonHoc=? " +
            "ELSE INSERT INTO MonHoc(MaMonHoc, TenMonHoc) " +
            "VALUES(?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sqlMH)) {

            ps.setString(1, maMH);
            ps.setString(2, tenMH);
            ps.setString(3, maMH);
            ps.setString(4, maMH);
            ps.setString(5, tenMH);

            ps.executeUpdate();
        }

        // Xoa dang ky cu cua sinh vien
        String sqlXoa =
            "DELETE FROM DangKyMonHoc WHERE MaSinhVien=?";

        try (PreparedStatement ps = conn.prepareStatement(sqlXoa)) {
            ps.setString(1, maSV);
            ps.executeUpdate();
        }

        // Them dang ky mon hoc moi
        String sqlDK =
            "INSERT INTO DangKyMonHoc(MaSinhVien, MaMonHoc) " +
            "VALUES(?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sqlDK)) {

            ps.setString(1, maSV);
            ps.setString(2, maMH);

            ps.executeUpdate();
        }
    }

    // =====================================
    // 5. THEM SINH VIEN VAO SQL
    // =====================================

    private void themSinhVien() {

        if (!kiemTraDuLieu()) return;

        if (conn == null) {
            JOptionPane.showMessageDialog(
                this, "Chua ket noi SQL Server!"
            );
            return;
        }

        try {

            conn.setAutoCommit(false);

            String sql =
                "INSERT INTO SinhVien " +
                "(MaSinhVien, HoVaTen, NamSinh, GioiTinh) " +
                "VALUES (?, ?, ?, ?)";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, txtMaSV.getText().trim());

                ps.setString(2, txtHoTen.getText().trim());

                ps.setInt(3, Integer.parseInt(
                    txtNamSinh.getText().trim()
                ));

                ps.setString(4,
                    cbGioiTinh.getSelectedItem().toString()
                );

                ps.executeUpdate();
            }

            // Luu mon hoc va dang ky vao SQL
            luuMonHoc(txtMaSV.getText().trim());

            conn.commit();

            JOptionPane.showMessageDialog(
                this,
                "THEM SINH VIEN THANH CONG!\nDu lieu da luu vao SQL Server."
            );

        } catch (SQLException e) {

            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(
                this,
                "LOI THEM SINH VIEN:\n" + e.getMessage()
            );

        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        hienThiDanhSach();
        lamMoi();
    }

    // =====================================
    // 6. SUA SINH VIEN TRONG SQL
    // =====================================

    private void suaSinhVien() {

        if (!kiemTraDuLieu()) return;

        if (conn == null) return;

        try {

            conn.setAutoCommit(false);

            String sql =
                "UPDATE SinhVien SET " +
                "HoVaTen=?, NamSinh=?, GioiTinh=? " +
                "WHERE MaSinhVien=?";

            int kq;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, txtHoTen.getText().trim());

                ps.setInt(2, Integer.parseInt(
                    txtNamSinh.getText().trim()
                ));

                ps.setString(3,
                    cbGioiTinh.getSelectedItem().toString()
                );

                ps.setString(4, txtMaSV.getText().trim());

                kq = ps.executeUpdate();
            }

            if (kq == 0) {

                conn.rollback();

                JOptionPane.showMessageDialog(
                    this, "Khong tim thay sinh vien!"
                );

                return;
            }

            // Cap nhat mon hoc va dang ky
            // Neu bo trong ma mon hoc thi giu dang ky cu
            if (!txtMaMH.getText().trim().isEmpty()
                    || !txtTenMH.getText().trim().isEmpty()) {

                luuMonHoc(txtMaSV.getText().trim());
            }

            conn.commit();

            JOptionPane.showMessageDialog(
                this,
                "SUA SINH VIEN THANH CONG!\nDu lieu da cap nhat trong SQL."
            );

        } catch (SQLException e) {

            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(
                this, "LOI SUA: " + e.getMessage()
            );

        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        hienThiDanhSach();
        lamMoi();
    }

    // =====================================
    // 7. XOA SINH VIEN TRONG SQL
    // =====================================

    private void xoaSinhVien() {

        String maSV = txtMaSV.getText().trim();

        if (maSV.isEmpty()) {

            JOptionPane.showMessageDialog(
                this, "Vui long chon sinh vien can xoa!"
            );

            return;
        }

        int chon = JOptionPane.showConfirmDialog(
            this,
            "Ban co chac chan muon xoa sinh vien " + maSV + "?",
            "XAC NHAN XOA",
            JOptionPane.YES_NO_OPTION
        );

        if (chon != JOptionPane.YES_OPTION) return;

        if (conn == null) return;

        try {

            conn.setAutoCommit(false);

            // Xoa dang ky mon hoc truoc
            String sqlDK =
                "DELETE FROM DangKyMonHoc WHERE MaSinhVien=?";

            try (PreparedStatement ps = conn.prepareStatement(sqlDK)) {

                ps.setString(1, maSV);
                ps.executeUpdate();
            }

            // Xoa sinh vien
            String sqlSV =
                "DELETE FROM SinhVien WHERE MaSinhVien=?";

            int kq;

            try (PreparedStatement ps = conn.prepareStatement(sqlSV)) {

                ps.setString(1, maSV);
                kq = ps.executeUpdate();
            }

            if (kq > 0) {

                conn.commit();

                JOptionPane.showMessageDialog(
                    this,
                    "XOA SINH VIEN THANH CONG!\nDu lieu da xoa trong SQL."
                );

            } else {

                conn.rollback();

                JOptionPane.showMessageDialog(
                    this, "Khong tim thay sinh vien!"
                );
            }

        } catch (SQLException e) {

            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(
                this, "LOI XOA: " + e.getMessage()
            );

        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        hienThiDanhSach();
        lamMoi();
    }

    // =====================================
    // 8. HIEN THI DU LIEU TU SQL
    // =====================================

    private void hienThiDanhSach() {

        if (conn == null) return;

        model.setRowCount(0);

        String sql =
            "SELECT SV.MaSinhVien, SV.HoVaTen, " +
            "SV.NamSinh, SV.GioiTinh, " +
            "MH.MaMonHoc, MH.TenMonHoc " +
            "FROM SinhVien SV " +
            "LEFT JOIN DangKyMonHoc DK " +
            "ON SV.MaSinhVien = DK.MaSinhVien " +
            "LEFT JOIN MonHoc MH " +
            "ON DK.MaMonHoc = MH.MaMonHoc " +
            "ORDER BY SV.MaSinhVien";

        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                model.addRow(new Object[]{

                    rs.getString("MaSinhVien"),

                    rs.getString("HoVaTen"),

                    rs.getInt("NamSinh"),

                    rs.getString("GioiTinh"),

                    rs.getString("MaMonHoc"),

                    rs.getString("TenMonHoc")
                });
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this, "LOI HIEN THI: " + e.getMessage()
            );
        }
    }

    // =====================================
    // 9. TIM KIEM SINH VIEN
    // =====================================

    private void timKiem() {

        if (conn == null) return;

        model.setRowCount(0);

        String sql =
            "SELECT SV.MaSinhVien, SV.HoVaTen, " +
            "SV.NamSinh, SV.GioiTinh, " +
            "MH.MaMonHoc, MH.TenMonHoc " +
            "FROM SinhVien SV " +
            "LEFT JOIN DangKyMonHoc DK " +
            "ON SV.MaSinhVien = DK.MaSinhVien " +
            "LEFT JOIN MonHoc MH " +
            "ON DK.MaMonHoc = MH.MaMonHoc " +
            "WHERE SV.MaSinhVien LIKE ? " +
            "OR SV.HoVaTen LIKE ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            String tuKhoa =
                "%" + txtTimKiem.getText().trim() + "%";

            ps.setString(1, tuKhoa);
            ps.setString(2, tuKhoa);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    model.addRow(new Object[]{

                        rs.getString("MaSinhVien"),

                        rs.getString("HoVaTen"),

                        rs.getInt("NamSinh"),

                        rs.getString("GioiTinh"),

                        rs.getString("MaMonHoc"),

                        rs.getString("TenMonHoc")
                    });
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this, "LOI TIM KIEM: " + e.getMessage()
            );
        }
    }

    // =====================================
    // 10. LAM MOI FORM
    // =====================================

    private void lamMoi() {

        txtMaSV.setEditable(true);

        txtMaSV.setText("");
        txtHoTen.setText("");
        txtNamSinh.setText("");
        txtMaMH.setText("");
        txtTenMH.setText("");

        txtTimKiem.setText("");

        cbGioiTinh.setSelectedIndex(0);

        table.clearSelection();
    }

    // =====================================
    // 11. CHAY CHUONG TRINH
    // =====================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new GiaoDienQuanLySinhVien().setVisible(true);

        });
    }
}
